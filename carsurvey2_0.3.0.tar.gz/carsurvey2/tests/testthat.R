library(testthat)
library("carsurvey2")

test_check("carsurvey2")